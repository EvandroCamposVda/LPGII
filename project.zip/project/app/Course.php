<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    protected $fillable = ['name', 'menu', 'student'];

    public function matriculation()
    {
        return $this->hasMany('App\Matriculation');
    }
}
