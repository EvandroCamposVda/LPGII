<?php

namespace App;

use Illuminate\Database\Query\Builder;
use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    protected $fillable = ['name', 'menu', 'student'];

    public function users()
    {
        return $this->belongsToMany('App\User')->withPivot('authorized');
    }
}
