<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    protected $fillable = ['name', 'cpf', 'rg', 'address', 'phone'];

    public function matriculation()
    {
        return $this->hasMany('App\Matriculation');
    }
}
