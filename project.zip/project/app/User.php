<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'privilege', 'cpf', 'rg', 'address', 'phone', 'password'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
}

class Student extends Model
{
    protected $fillable = ['name', 'email', 'privilege', 'cpf', 'rg', 'address', 'phone', 'password'];

    public function matriculation()
    {
        return $this->hasMany('App\Matriculation');
    }
}
