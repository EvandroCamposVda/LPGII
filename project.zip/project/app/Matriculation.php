<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Matriculation extends Model
{
    protected $fillable = ['authorized', 'user_id', 'course_id'];

    public function course()
    {
        return $this->belongsTo('App\Course');
    }

    public function Student()
    {
        return $this->belongsTo('App\User');
    }
}
