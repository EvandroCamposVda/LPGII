<?php

namespace App\Http\Controllers ;

use Illuminate\Http\Request;
use App\Student;

class StudentController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $student = Student::all();

        return view('students/index', ['students' => $student]);
    }

    public function create() 
    {
        return view('students/new');
    }

    public function store(Request $request) 
    {
        $s = new Student;
        $s->name = $request->input('name');
        $s->cpf = $request->input('cpf');
        $s->rg = $request->input('rg');
        $s->address = $request->input('address');
        $s->phone = $request->input('phone');
        
        if ($s->save()) {
            \Session::flash('status', 'Estudante cadastrado com sucesso.');
            return redirect('/students');
        } else {
            \Session::flash('status', 'Ocorreu um erro ao cadastrar o estudante.');
            return view('students.new');
        }
    }

    public function edit($id) {
        $student = Student::findOrFail($id);
        return view('students.edit', ['students' => $student]);
    }

    public function update(Request $request, $id) {
        $s = Student::findOrFail($id);
        $s->name = $request->input('name');
        $s->cpf = $request->input('cpf');
        $s->rg = $request->input('rg');
        $s->address = $request->input('address');
        $s->phone = $request->input('phone');
        
        if ($s->save()) {
            \Session::flash('status', 'Estudante atualizado com sucesso.');
            return redirect('/students');
        } else {
            \Session::flash('status', 'Ocorreu um erro ao atualizar o estudante.');
            return view('students.edit', ['students' => $s]);
        }
    }

    public function destroy($id) {
        $s = Student::findOrFail($id);
        $s->delete();

        \Session::flash('status', 'Curso excluído com sucesso.');
        return redirect('/students');
    }
}
