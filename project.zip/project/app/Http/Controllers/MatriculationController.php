<?php

namespace App\Http\Controllers ;

use App\User;
use App\Course;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class MatriculationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        //$matriculations = Course::whereIn('id', Auth::user()->id)->get();

        
        $user = Auth::user();
        if($user->privilege == 'Administrador')
        {            
            //$user = User::all();
            $matriculations = DB::table('course_user')
                ->join('users', 'course_user.user_id', '=', 'users.id')
                ->join('courses', 'course_user.course_id', '=', 'courses.id')
                ->select('course_user.id', 'course_user.authorized','users.name as user', 'courses.name', 'course_user.created_at')
                ->paginate(10);
                return view('matriculations/adminIndex', ['matriculation' => $matriculations, 'user' => $user]);
        }else 
        {
            //$matriculations = User::find($user->id)->courses;
            $matriculations = DB::table('course_user')
                ->join('users', 'course_user.user_id', '=', 'users.id')
                ->join('courses', 'course_user.course_id', '=', 'courses.id')
                ->select('course_user.id', 'course_user.authorized','users.name as user', 'courses.name', 'course_user.created_at')
                ->where('course_user.user_id', $user->id)
                ->paginate(10);
            return view('matriculations/index', ['matriculation' => $matriculations, 'user' => $user]);
        }
       
        //dd($matriculations);
        //$matriculations = DB::table('course_user')->where('user_id', $user->id)->get();
        //$matriculations = Course::find($user->id)->users()->get();
        //$matriculations = DB::table('course_user')->where('user_id', $user->id)->get();
        //$matriculations = Course::all()->where('user_id', $user->id)->get();
        //$courses = User::find($user->id)->courses()->wherePivot('id', $user->id)->get();
        //dd($matriculations);
    }

    public function create() 
    {   
        $me = Auth::user(); 
        
        $course = Course::whereNotIn('id', $me->courses->pluck('id'))->get();

        return view('matriculations/new', ['course' => $course, 'user' => $me]);
    }

    public function store(Request $request) 
    {   
        $user = Auth::user();
        $user->courses()->attach($request->input('course_id'), ['authorized' => false]);        
        
        \Session::flash('status', 'Matricula efetuada com sucesso.');
        return redirect('/matriculations');
   
    }

    public function edit($id) {
            $matriculation = DB::table('course_user')
                ->join('users', 'course_user.user_id', '=', 'users.id')
                ->join('courses', 'course_user.course_id', '=', 'courses.id')
                ->select('course_user.id as id', 'course_user.authorized as authorized','users.name as user', 'courses.name as course', 'course_user.created_at as created_at')
                ->where('course_user.id', $id)->get();

        return view('matriculations.edit', ['matriculation' => $matriculation]);    
    }

    public function update(Request $request, $id) {
        $matriculation = DB::table('course_user')
                ->join('users', 'course_user.user_id', '=', 'users.id')
                ->select('course_user.user_id as user_id', 'course_user.course_id as course_id')
                ->where('course_user.id', $id)->get();

        foreach($matriculation as $matriculations){
            $course = Course::find($matriculations->course_id);
            $user = User::find($matriculations->user_id);
        }


            if ($request->authorized == 1){
                $user->courses()->updateExistingPivot($course->id, ['authorized' => true]);
            }else {
                $user->courses()->updateExistingPivot($course->id, ['authorized' => false]);
            }
        
            if ($user->save()) {
             \Session::flash('status', 'Matricula atualizada com sucesso.');
               return redirect('/matriculations');
         } else {
             \Session::flash('status', 'Ocorreu um erro ao atualizar a matricula.');
             return view('matriculations.edit', ['matriculations']);
         }
    }

    public function destroy($id) {
        $matriculation = DB::table('course_user')
                ->join('users', 'course_user.user_id', '=', 'users.id')
                ->select('course_user.user_id as user_id', 'course_user.course_id as course_id', 'course_user.id as id')
                ->where('course_user.id', $id)->get();

        foreach($matriculation as $m){
            $matriculation = DB::table('course_user')->find($m->id);
        }

        $user = User::find($matriculation->user_id);
        $course = Course::find($matriculation->course_id);

        $user->courses()->detach($matriculation->course_id);

        \Session::flash('status', 'Matricula excluído com sucesso.');
        return redirect('/matriculations');
    }
}
