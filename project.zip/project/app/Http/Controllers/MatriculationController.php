<?php

namespace App\Http\Controllers ;

use Illuminate\Http\Request;
use App\User;
use App\Matriculation;
use App\Course;

class MatriculationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $matriculation = Matriculation::all();
        $user = User::all();
        $course = Course::all();
        return view('matriculations/index', ['matriculations' => $matriculation], ['course' => $course], ['user' => $user]);
    }

    public function create() 
    {   
        $user = User::all();
        $course = Course::all();
        return view('matriculations/new', ['course' => $course], ['user' => $user]);
    }

    public function store(Request $request) 
    {   
        $m = new Matriculation;
        $m->authorized = "0";
        $m->student_id = $request->input('student_id');
        $m->course_id = $request->input('course_id');
        
        
        if ($m->save()) {
            \Session::flash('status', 'Matricula efetuada com sucesso.');
            return redirect('/matriculations');
        } else {
            \Session::flash('status', 'Ocorreu um erro ao fazer a matricula.');
            return view('matriculations.new');
        }
    }

    public function edit($id) {
        $matriculation = Matriculation::findOrFail($id);
        $course = Course::all();
        $user = User::all();
    
        return view('matriculations.edit', ['matriculation' => $matriculation], ['course' => $course], ['user' => $user]);

    }

    public function update(Request $request, $id) {
        $m = Matriculation::findOrFail($id);
        $m->authorized = $request->input('authorized');
        $m->student_id = $request->input('student_id');
        $m->course_id = $request->input('course_id');
        
        if ($m->save()) {
            \Session::flash('status', 'Matricula atualizada com sucesso.');
            return redirect('/matriculations');
        } else {
            \Session::flash('status', 'Ocorreu um erro ao atualizar a matricula.');
            return view('matriculations.edit', ['matriculations' => $m]);
        }
    }

    public function destroy($id) {
        $m = Matriculation::findOrFail($id);
        $m->delete();

        \Session::flash('status', 'Matricula excluído com sucesso.');
        return redirect('/matriculations');
    }
}
