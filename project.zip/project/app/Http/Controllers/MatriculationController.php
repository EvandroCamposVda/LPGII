<?php

namespace App\Http\Controllers ;

use Illuminate\Http\Request;
use App\Matriculation;

class MatriculationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $matriculation = Matriculation::all();

        return view('matriculations/index', ['matriculations' => $matriculation]);
    }

    public function create() 
    {
        return view('matriculations/new');
    }

    public function store(Request $request) 
    {
        $m = new Matriculation;
        $m->authorized = $request->input('authorized');
        $m->student_id = $request->input('student_id');
        $m->course_id = $request->input('course_id');
        
        if ($s->save()) {
            \Session::flash('status', 'Matricula efetuada com sucesso.');
            return redirect('/matriculations');
        } else {
            \Session::flash('status', 'Ocorreu um erro ao fazer a matricula.');
            return view('matriculations.new');
        }
    }

    public function edit($id) {
        $matriculation = Matriculation::findOrFail($id);

        return view('matriculations.edit', ['matriculation' => $matriculation]);
    }

    public function update(Request $request, $id) {
        $m = Matriculation::findOrFail($id);
        $m->authorized = $request->input('authorized');
        $m->student_id = $request->input('student_id');
        $m->course_id = $request->input('course_id');
        
        if ($m->save()) {
            \Session::flash('status', 'Matricula atualizada com sucesso.');
            return redirect('/matriculations');
        } else {
            \Session::flash('status', 'Ocorreu um erro ao atualizar a matricula.');
            return view('matriculations.edit', ['matriculations' => $m]);
        }
    }

    public function destroy($id) {
        $m = Matriculation::findOrFail($id);
        $m->delete();

        \Session::flash('status', 'Matricula excluído com sucesso.');
        return redirect('/matriculations');
    }
}
