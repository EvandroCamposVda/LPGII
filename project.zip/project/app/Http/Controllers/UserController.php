<?php

namespace App\Http\Controllers ;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Database\Query\Builder;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Request\UserValidador;
use App\User;


class UserController extends Controller
{
    
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {   
        if(Auth::user()->privilege == 'Administrador')
        {            
            $user = User::all();
            return view('users/index', ['users' => $user]);
        }else 
        {
            $user = Auth::user();
            return view('users/studentIndex', ['users' => $user]);
        }
    }

    public function create() 
    {
        return view('users/new');
    }

    public function store(Request $request) 
    {
        $u = new User;
        $senha = $request->input('password');
        $confirSenha = $request->input('password_confirmation');
        $passwordMod = Hash::make($senha);

        $u->name = $request->input('name');
        $u->email = $request->input('email');
        $u->rg = $request->input('rg');
        $u->cpf = $request->input('cpf');
        $u->phone = $request->input('phone');
        $u->address = $request->input('address');
        $u->privilege = "Comum";
        $u->password = $passwordMod;

        
        if ($senha == $confirSenha && $u->save()) {
            \Session::flash('status', 'Estudante cadastrado com sucesso.');
            return redirect('/users');
        } else if ($senha != $confirSenha){
            \Session::flash('status', 'As senhas não conferem');
            return view('users.new');
        }else {
            \Session::flash('status', 'Ocorreu um erro ao cadastrar o estudante.');
            return view('users.new');
        }
    }

    public function edit($id) {
        $user = User::findOrFail($id);

        if(Auth::user()->privilege == 'Administrador')
        {            
            $user = User::findOrFail($id);
            return view('users.edit', ['users' => $user]);
        }else 
        {
            $user = User::findOrFail($id);
            return view('users.studentEdit', ['users' => $user]);
        }
    }

    public function update(Request $request, $id) {
        $u = User::findOrFail($id);
        $u->name = $request->input('name');
        $u->email = $request->input('email');
        $u->rg = $request->input('rg');
        $u->cpf = $request->input('cpf');
        $u->phone = $request->input('phone');
        $u->address = $request->input('address');
        $u->privilege = $request->input('privilege');

      
        
        if ($u->save()) {
            \Session::flash('status', 'Estudante atualizado com sucesso.');
            return redirect('/users');
        } else {
            \Session::flash('status', 'Ocorreu um erro ao atualizar o estudante.');
            return view('users.edit', ['users' => $u]);
        }
    }

    public function destroy($id) {
        $s = User::findOrFail($id);
        $s->delete();

        \Session::flash('status', 'Curso excluído com sucesso.');
        return redirect('/users');
    }
}
