<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UserValidador extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return false;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|max:265|string',
            'email' => 'required',
            'cpf' => 'required|max:11|integer',
            'rg' => 'required|max:9|integer',
            'address' => 'required|max:265',
            'phone' => 'required|max:265',
        ];
    }

    public function messages()
    {
        return [
            'name.max' => 'O nome deve conter apenas 265 caracteres !',
            'name.string' => 'O nome deve conter apenas letras !',
            'cpf.max' => 'O CPF deve conter apenas 11 digitos !',
            'cpf.integer' => 'O CPF deve conter apenas numeros !',
            'rg.max' => 'O RG deve conter no maximo 9 digitos !',
            'rg.integer' => 'O RG deve conter apenas numeros !',
            'address.max' => 'O Endereço deve conter no maximo 265 caracteres',
            'phone.max' => 'O Telefone deve conter no maximo 265 caracteres'
        ];
    }
}
