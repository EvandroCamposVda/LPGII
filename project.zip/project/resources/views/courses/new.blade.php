@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Novo Curso                    
                </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    {!! Form::open(['url' => '/courses', 'method' => 'post']) !!}
                        
                    <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Nome') }}</label>
    
                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name') }}" required autofocus>
    
                                @if ($errors->has('name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                                <label for="menu" class="col-md-4 col-form-label text-md-right">{{ __('Ementa') }}</label>
        
                                <div class="col-md-6">
                                    <input id="menu" type="text" class="form-control{{ $errors->has('menu') ? ' is-invalid' : '' }}" name="menu" value="{{ old('menu') }}" required autofocus>
        
                                    @if ($errors->has('menu'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('menu') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                        <div class="form-group row">
                                <label for="student" class="col-md-4 col-form-label text-md-right">{{ __('Quantidade Estudantes') }}</label>
        
                                <div class="col-md-6">
                                    <input id="student" type="text" class="form-control{{ $errors->has('student') ? ' is-invalid' : '' }}" name="student" value="{{ old('student') }}" required autofocus>
        
                                    @if ($errors->has('student'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('student') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                        <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        {{ __('Adicionar') }}
                                    </button>
                                </div>
                            </div>

                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
