@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    
                    <a href="/courses/create" class="float-right btn btn-success">Novo Curso</a>
                    Curso
                    <a href="/home" class="float btn btn-success">Inicio</a>
                </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <table class="table">
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Ementa</th>
                            <th>Quantidade Estudantes</th>
                            <th>Criado</th>
                            <th>Editar</th>
                            <th>Deletar</th>
                            
                        </tr>
                        
                        @foreach($courses as $c)
                            <tr>
                                <td>{{ $c->id }}</td>
                                <td>{{ $c->name }}</td>
                                <td>{{ $c->menu }}</td>
                                <td>{{ $c->student }}</td>
                                <td>{{ $c->created_at }}</td>
                                <td>
                                    <a href="/courses/{{ $c->id }}/edit" class="btn btn-primary btn-sm">Editar</a>
                                </td>
                                <td>
                                    {!! Form::open(['url' => "/courses/$c->id", 'method' => 'delete']) !!}
                                        {{ Form::submit('Deletar', ["class" => "btn btn-danger btn-sm"]) }}
                                    {!! Form::close() !!}
                                </td>
                                
                            </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
