@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Editando Matricula                    
                </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                        {{ dd($matriculation) }}
                    {!! Form::open(['url' => "/matriculations/$matriculation->id", 'method' => 'put']) !!}
                        

                        @csrf
                        <div class="form-group row">    
                                <label for="name" class="col-md-4 col-form-label text-md-right">{{ 'Nome: '}}</label>
                                <div class="col-md-6">
                                    <label for="student_id" name="student_id" class="form-control"> {{ $matriculation->user }}</label>
                                </div>
                        </div>

                        <div class="form-group row">    
                                <label for="course" class="col-md-4 col-form-label text-md-right">{{ 'Curso: '}}</label>
                                <div class="col-md-6">
                                    <label for="course_id" name="course_id" class="form-control">{{ $matriculation->course }}</label>
                                </div>
                        </div>

                        <div class="form-group row">
                                <label for="authorized" class="col-md-4 col-form-label text-md-right">{{ __('Autorizado') }}</label>
                                <div class='col-md-6'>
                                        
                                            
                                            @if( $user->privilege == 'Administrador')
                                                <select class="form-control" id="authorized" name="authorized">    
                                                    <option value="">Selecione</option>
                                                    <option value= 0>Não Autorizado</option>
                                                    <option value= 1>Autorizado</option>
                                                </select>
                                            @else 
                                                <label class="form-control">Não autorizado </label>
                                            @endif
                                </div>
                        </div>
                        
                        @if( $user->privilege == 'Administrador')
                        <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        {{ __('Salvar') }}
                                    </button>
                                </div>
                            </div>
                        @endif
                            
                    {!! Form::close() !!}

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
