@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Editando Matricula                    
                </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    {!! Form::open(['url' => "/matriculations/$matriculation->id", 'method' => 'put']) !!}
                        
                        {{ Form::label('student_id', 'Nome') }}
                        {{ Form::text('student_id', $matriculation->student->name, ['class' => "form-control"]) }}

                        <br>
                        <br>

                        {{ Form::label('authorized', 'Autorizado') }}
                        {{ Form::text('authorized', $matriculation->authorized) }}

                        <br>
                        <br>

                        {{ Form::label('course_id', 'Cursos') }}
                    
                    
                        <Select>
                            @foreach($course as $c)
                                <option name="course_id" value={{$c->id}}>
                                    {{$c->name}}
                                </option>
                            @endforeach
                        </select>
                   
                        <br />
                        
                        {{ Form::submit('Salvar') }}

                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
