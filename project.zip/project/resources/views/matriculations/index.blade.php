@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    
                    <a href="/matriculations/create" class="float-right btn btn-success">Nova Matricula</a>
                    Matricula
                    <a href="/home" class="float btn btn-success">Inicio</a>
                </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <table class="table">
                        <tr>
                            <th>ID</th>
                            <th>Aluno</th>
                            <th>Matéria</th>
                            <th>Autorizado</th>
                            <th>Inscrito</th>
                            <th>Editar</th>
                            <th>Deletar</th>
                        </tr>
                        
                        @foreach($matriculations as $m)
                            <tr>
                                
                                <td>{{ $m->id }}</td>
                                <td>{{ $m->student->name }}</td>
                                <td>{{ $m->course->name }}</td>
                                <td>{{ $m->authorized }}</td>
                                <td>{{ $m->created_at }}</td>
                                <td>
                                    <a href="/matriculations/{{ $m->id }}/edit" class="btn btn-primary btn-sm">Editar</a>
                                </td>
                                <td>
                                    {!! Form::open(['url' => "/matriculations/$m->id", 'method' => 'delete']) !!}
                                    {{ Form::submit('Deletar', ["class" => "btn btn-danger btn-sm"]) }}
                                    {!! Form::close() !!}
                                </td>
                            </tr>
                        @endforeach
                        
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
