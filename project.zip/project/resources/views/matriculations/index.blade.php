@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    
                    <a href="/matriculations/create" class="float-right btn btn-success">Nova Matricula</a>
                    Matricula
                    <a href="/home" class="float btn btn-success">Inicio</a>
                </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <table class="table">
                        <tr>
                            <th>ID</th>
                            <th>Aluno</th>
                            <th>Matéria</th>
                            <th>Autorizado</th>
                            <th>Inscrito</th>
                            @if( $user->privilege == 'Administrador')
                                <th>Editar</th>
                            @endif
                            <th>Deletar</th>
                        </tr>
                        @foreach($matriculation as $m)
                            <tr>
                                <td>{{ $m->id }}</td>
                                <td>{{ $m->user }}</td>
                                <td>{{ $m->name }}</td>
                                @if( $m->authorized == 0)
                                    <td>Não</td>
                                @else 
                                    <td>Sim</td>
                                @endif
                                <td>{{ $m->created_at }}</td>
                                @if( $user->privilege == 'Administrador')
                                    <td>
                                        <a href="/matriculations/{{ $m->id }}/edit" class="btn btn-primary btn-sm">Editar</a>
                                    </td>
                                    @endif
                                <td>
                                    {!! Form::open(['url' => "/matriculations/$m->id", 'method' => 'delete']) !!}
                                    {{ Form::submit('Deletar', ["class" => "btn btn-danger btn-sm"]) }}
                                    {!! Form::close() !!}
                                </td>
                            </tr>
                        @endforeach
                        {{ $matriculation->links() }}
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
