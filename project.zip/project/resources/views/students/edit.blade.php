@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Editando Estudante                    
                </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    {!! Form::open(['url' => "/students/$students->id", 'method' => 'put']) !!}
                        
                        {{ Form::label('name', 'Nome') }}
                        {{ Form::text('name', $students->name) }}

                        <br /><br />

                        {{ Form::label('cpf', 'CPF') }}
                        {{ Form::text('cpf', $students->cpf) }}

                        <br /><br />

                        {{ Form::label('rg', 'RG') }}
                        {{ Form::text('rg', $students->rg) }}

                        <br /><br />
                        
                        {{ Form::label('address', 'Endereço') }}
                        {{ Form::text('address', $students->address) }}

                        <br /><br />
                        
                        {{ Form::label('phone', 'Telefone') }}
                        {{ Form::text('phone', $students->phone) }}

                        <br /><br />

                        {{ Form::submit('Salvar') }}

                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
