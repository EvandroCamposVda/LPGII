@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    
                    <a href="/students/create" class="float-right btn btn-success">Novo Estudante</a>
                    Estudantes
                    <a href="/home" class="float btn btn-success">Inicio</a>
                </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <table class="table">
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>CPF</th>
                            <th>RG</th>
                            <th>Endereço</th>
                            <th>Telefone</th>
                            <th>Matriculado</th>
                            <th>Opções</th>
                        </tr>
                        
                        @foreach($students as $s)
                            <tr>
                                <td>{{ $s->id }}</td>
                                <td>{{ $s->name }}</td>
                                <td>{{ $s->cpf }}</td>
                                <td>{{ $s->rg }}</td>
                                <td>{{ $s->address }}</td>
                                <td>{{ $s->phone }}</td>
                                <td>{{ $s->created_at }}</td>
                                <td>
                                    <a href="/students/{{ $s->id }}/edit" class="btn btn-primary btn-sm">Editar</a>

                                    {!! Form::open(['url' => "/students/$s->id", 'method' => 'delete']) !!}
                                        {{ Form::submit('Deletar', null, ["class" => "btn btn-warning"]) }}
                                    {!! Form::close() !!}
                                </td>
                            </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
