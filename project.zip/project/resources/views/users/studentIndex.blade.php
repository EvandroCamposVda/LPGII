@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Estudante
                    <a href="/home" class="float-right btn btn-success">Inicio</a>
                </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <table class="table">
                        <tr>
                            <th>ID</th>
                            <th>Aluno</th>
                            <th>Email</th>
                            <th>Privilegio</th>
                            <th>Criado</th>
                            <th>Editar</th>
                            <th>Deletar</th>
                        </tr>

                            <tr>
                                <td>{{ $users->id }}</td>
                                <td>{{ $users->name }}</td>
                                <td>{{ $users->email }}</td>
                                <td>{{ $users->privilege}}</td>
                                <td>{{ $users->created_at }}</td>
                                <td>
                                    <a href="/users/{{ $users->id }}/edit" class="btn btn-primary btn-sm">Editar</a>
                                </td>
                                <td>
                                    {!! Form::open(['url' => "/users/$users->id", 'method' => 'delete']) !!}
                                        {{ Form::submit('Deletar', ["class" => "btn btn-danger btn-sm"]) }}
                                    {!! Form::close() !!}
                                </td>
                            </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
