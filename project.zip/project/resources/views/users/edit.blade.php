@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Editando acesso Aluno                    
                </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    {!! Form::open(['url' => "/users/$users->id", 'method' => 'put']) !!}
                        
                        @csrf

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Nome') }}</label>

                            <div class="col-md-6"><!--Aparecendo somente o primeiro nome-->

                                {{ Form::text('name', $users->name, ['class' => "form-control"], $errors->has('name') ? ' is-invalid' : '') }}

                                @if ($errors->has('name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                                <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>
        
                                <div class="col-md-6">
                                    {{ Form::text('email', $users->email, ['class' => "form-control"], $errors->has('email') ? ' is-invalid' : '') }}
                                    @if ($errors->has('email'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('email') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                        <div class="form-group row">
                                <label for="cpf" class="col-md-4 col-form-label text-md-right">{{ __('CPF') }}</label>
        
                                <div class="col-md-6">
                                    
                                    {{ Form::text('cpf', $users->cpf, ['class' => "form-control"], $errors->has('cpf') ? ' is-invalid' : '') }}

                                    @if ($errors->has('cpf'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('cpf') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                        
                        <div class="form-group row">
                            <label for="rg" class="col-md-4 col-form-label text-md-right">{{ __('RG') }}</label>
    
                            <div class="col-md-6">
                                
                                {{ Form::text('rg', $users->rg, ['class' => "form-control"], $errors->has('rg') ? ' is-invalid' : '') }}

                                @if ($errors->has('rg'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('rg') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                                <label for="address" class="col-md-4 col-form-label text-md-right">{{ __('Endereço') }}</label>
                                
                                <div class="col-md-6">
                                    {{ Form::text('address', $users->address, ['class' => "form-control"], $errors->has('address') ? ' is-invalid' : '') }}
                                    
                                    @if ($errors->has('address'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('address') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                        
                        <div class="form-group row">
                                <label for="phone" class="col-md-4 col-form-label text-md-right">{{ __('Telefone') }}</label>
        
                                <div class="col-md-6">
                                    
                                    {{ Form::text('phone', $users->phone, ['class' => "form-control"], $errors->has('phone') ? ' is-invalid' : '') }}
                                    
                                    @if ($errors->has('phone'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('phone') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                        
                        <div class="form-group row">
                                <label for="privileges" class="col-md-4 col-form-label text-md-right">{{ __('Privilégios') }}</label>
                                    <div class='col-md-6'>
                                        <select class="form-control" id="privileges" name="privilege">
                                            <option value="">Selecione</option>
                                            <option value="Comum" name="privilege" for="privileges">Comum</option>
                                            <option value="Administrador" name="privilege" for="privileges">Administrador</option>
                                        </select>
                                    </div>
                        </div>
                        
                        <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        {{ __('Register') }}
                                    </button>
                                </div>
                            </div>

                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
