@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    
                    <a href="/users/create" class="float-right btn btn-success">Novo Estudante</a>
                    Estudante
                    <a href="/home" class="float btn btn-success">Inicio</a>
                </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <table class="table">
                        <tr>
                            <th>ID</th>
                            <th>Aluno</th>
                            <th>Email</th>
                            <th>Privilegio</th>
                            <th>Criado</th>
                            <th>Editar</th>
                            <th>Deletar</th>
                        </tr>
                        
                        @foreach($users as $u)
                            <tr>
                                <td>{{ $u->id }}</td>
                                <td>{{ $u->name }}</td>
                                <td>{{ $u->email }}</td>
                                <td>{{ $u->privilege}}</td>
                                <td>{{ $u->created_at }}</td>
                                <td>
                                    <a href="/users/{{ $u->id }}/edit" class="btn btn-primary btn-sm">Editar</a>
                                </td>
                                <td>
                                    {!! Form::open(['url' => "/users/$u->id", 'method' => 'delete']) !!}
                                        {{ Form::submit('Deletar', ["class" => "btn btn-danger btn-sm"]) }}
                                    {!! Form::close() !!}
                                </td>
                            </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
