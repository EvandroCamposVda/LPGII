

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Editando Matricula                    
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo Form::open(['url' => "/matriculations/$matriculation->id", 'method' => 'put']); ?>

                        
                        <?php echo e(Form::label('student_id', 'Nome')); ?>

                        <?php echo e(Form::text('student_id', $matriculation->student->name, ['class' => "form-control"])); ?>


                        <br>
                        <br>

                        <?php echo e(Form::label('authorized', 'Autorizado')); ?>

                        <?php echo e(Form::text('authorized', $matriculation->authorized)); ?>


                        <br>
                        <br>

                        <?php echo e(Form::label('course_id', 'Cursos')); ?>

                    
                    
                        <Select>
                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option name="course_id" value=<?php echo e($c->id); ?>>
                                    <?php echo e($c->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                   
                        <br />
                        
                        <?php echo e(Form::submit('Salvar')); ?>


                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>