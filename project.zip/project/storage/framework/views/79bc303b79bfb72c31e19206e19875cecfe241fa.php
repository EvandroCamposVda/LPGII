

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    
                    <a href="/matriculations/create" class="float-right btn btn-success">Nova Matricula</a>
                    Matricula
                    <a href="/home" class="float btn btn-success">Inicio</a>
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table">
                        <tr>
                            <th>ID</th>
                            <th>Aluno</th>
                            <th>Matéria</th>
                            <th>Autorizado</th>
                            <th>Inscrito</th>
                            <?php if( $user->privilege == 'Administrador'): ?>
                                <th>Editar</th>
                            <?php endif; ?>
                            <th>Deletar</th>
                        </tr>
                        
                        <?php $__currentLoopData = $matriculation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($m->id); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($m->name); ?></td>
                                <?php if( $m->authorized == 0): ?>
                                    <td>Não</td>
                                <?php else: ?> 
                                    <td>Sim</td>
                                <?php endif; ?>
                                <td><?php echo e($m->created_at); ?></td>
                                <?php if( $user->privilege == 'Administrador'): ?>
                                    <td>
                                        <a href="/matriculations/<?php echo e($m->id); ?>/edit" class="btn btn-primary btn-sm">Editar</a>
                                    </td>
                                    <?php endif; ?>
                                <td>
                                    <?php echo Form::open(['url' => "/matriculations/$m->id", 'method' => 'delete']); ?>

                                    <?php echo e(Form::submit('Deletar', ["class" => "btn btn-danger btn-sm"])); ?>

                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>