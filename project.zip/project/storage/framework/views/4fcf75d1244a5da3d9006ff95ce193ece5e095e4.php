

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    
                    <a href="/users/create" class="float-right btn btn-success">Novo Estudante</a>
                    Estudante
                    <a href="/home" class="float btn btn-success">Inicio</a>
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table">
                        <tr>
                            <th>ID</th>
                            <th>Aluno</th>
                            <th>Email</th>
                            <th>Privilegio</th>
                            <th>Criado</th>
                            <th>Editar</th>
                            <th>Deletar</th>
                        </tr>
                        
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($u->id); ?></td>
                                <td><?php echo e($u->name); ?></td>
                                <td><?php echo e($u->email); ?></td>
                                <td><?php echo e($u->privilege); ?></td>
                                <td><?php echo e($u->created_at); ?></td>
                                <td>
                                    <a href="/users/<?php echo e($u->id); ?>/edit" class="btn btn-primary btn-sm">Editar</a>
                                </td>
                                <td>
                                    <?php echo Form::open(['url' => "/users/$u->id", 'method' => 'delete']); ?>

                                        <?php echo e(Form::submit('Deletar', ["class" => "btn btn-danger btn-sm"])); ?>

                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>