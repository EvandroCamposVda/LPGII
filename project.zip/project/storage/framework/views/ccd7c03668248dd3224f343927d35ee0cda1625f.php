

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Editando acesso Aluno                    
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo Form::open(['url' => "/users/$users->id", 'method' => 'put']); ?>

                        
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nome')); ?></label>

                            <div class="col-md-6"><!--Aparecendo somente o primeiro nome-->

                                <?php echo e(Form::text('name', $users->name, ['class' => "form-control"], $errors->has('name') ? ' is-invalid' : '')); ?>


                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                                <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>
        
                                <div class="col-md-6">
                                    <?php echo e(Form::text('email', $users->email, ['class' => "form-control"], $errors->has('email') ? ' is-invalid' : '')); ?>

                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                        <div class="form-group row">
                                <label for="cpf" class="col-md-4 col-form-label text-md-right"><?php echo e(__('CPF')); ?></label>
        
                                <div class="col-md-6">
                                    
                                    <?php echo e(Form::text('cpf', $users->cpf, ['class' => "form-control"], $errors->has('cpf') ? ' is-invalid' : '')); ?>


                                    <?php if($errors->has('cpf')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('cpf')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        
                        <div class="form-group row">
                            <label for="rg" class="col-md-4 col-form-label text-md-right"><?php echo e(__('RG')); ?></label>
    
                            <div class="col-md-6">
                                
                                <?php echo e(Form::text('rg', $users->rg, ['class' => "form-control"], $errors->has('rg') ? ' is-invalid' : '')); ?>


                                <?php if($errors->has('rg')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('rg')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                                <label for="address" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Endereço')); ?></label>
                                
                                <div class="col-md-6">
                                    <?php echo e(Form::text('address', $users->address, ['class' => "form-control"], $errors->has('address') ? ' is-invalid' : '')); ?>

                                    
                                    <?php if($errors->has('address')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('address')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        
                        <div class="form-group row">
                                <label for="phone" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Telefone')); ?></label>
        
                                <div class="col-md-6">
                                    
                                    <?php echo e(Form::text('phone', $users->phone, ['class' => "form-control"], $errors->has('phone') ? ' is-invalid' : '')); ?>

                                    
                                    <?php if($errors->has('phone')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('phone')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        
                        <div class="form-group row">
                                <label for="privileges" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Privilégios')); ?></label>
                                    <div class='col-md-6'>
                                        <select class="form-control" id="privileges" name="privilege">
                                            <option value="Comum" name="privilege" for="privileges">Comum</option>
                                        </select>
                                    </div>
                        </div>
                        
                        <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Register')); ?>

                                    </button>
                                </div>
                            </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>