

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Nova Matricula                    
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo Form::open(['url' => '/matriculations', 'method' => 'post']); ?>

                    <!--BUUUUUUUUUUUUUUUUUUUUUUUUGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG Nao Passa o ID-->
                    
                    <label for="nome" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nome')); ?></label> 

                    <label for="name" class="col-md-4 col-form-label"><?php echo e($user->name); ?></label>

                    <div class="form-group row">
                        <label for="course" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Cursos')); ?></label>
                            <div class='col-md-6'>
                                <select class="form-control" id="course" name="course_id">
                                    <option>
                                        Selecione
                                    </option>
                                    <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option for="course" name="course_id" value=<?php echo e($c->id); ?>>
                                            <?php echo e($c->name); ?>

                                        </option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                            </div>
                    </div>

                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Cadastrar')); ?>

                            </button>
                        </div>
                    </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>