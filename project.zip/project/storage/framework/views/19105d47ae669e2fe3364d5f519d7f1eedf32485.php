

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Editando Estudante                    
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo Form::open(['url' => "/students/$students->id", 'method' => 'put']); ?>

                        
                        <?php echo e(Form::label('name', 'Nome')); ?>

                        <?php echo e(Form::text('name', $students->name)); ?>


                        <br /><br />

                        <?php echo e(Form::label('cpf', 'CPF')); ?>

                        <?php echo e(Form::text('cpf', $students->cpf)); ?>


                        <br /><br />

                        <?php echo e(Form::label('rg', 'RG')); ?>

                        <?php echo e(Form::text('rg', $students->rg)); ?>


                        <br /><br />
                        
                        <?php echo e(Form::label('address', 'Endereço')); ?>

                        <?php echo e(Form::text('address', $students->address)); ?>


                        <br /><br />
                        
                        <?php echo e(Form::label('phone', 'Telefone')); ?>

                        <?php echo e(Form::text('phone', $students->phone)); ?>


                        <br /><br />

                        <?php echo e(Form::submit('Salvar')); ?>


                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>