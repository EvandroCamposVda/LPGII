

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Editando Curso                    
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo Form::open(['url' => "/courses/$courses->id", 'method' => 'put']); ?>

                        
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nome')); ?></label>

                            <div class="col-md-6"><!--Aparecendo somente o primeiro nome-->
                                
                                <?php echo e(Form::text('name', $courses->name, ['class' => "form-control"], $errors->has('name') ? ' is-invalid' : '')); ?>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="menu" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ementa')); ?></label>
                            <div class="col-md-6">  
                                    <?php echo e(Form:: textarea ('menu', $courses->menu, array('placeholder' => 'Ementa do curso', 'class' => 'form-control', 'id' => 'menu', 'rows' => '4' ))); ?>

                            </div>
                            <?php if($errors->has('menu')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('menu')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>

                        <div class="form-group row">
                                <label for="student" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Capacidade Alunos')); ?></label>
    
                                <div class="col-md-6"><!--Aparecendo somente o primeiro nome-->
                                   
                                    <input id="student" type="text" class="form-control<?php echo e($errors->has('student') ? ' is-invalid' : ''); ?>" name="student" value=<?php echo e($courses->student); ?> required autofocus>
    
                                    <?php if($errors->has('student')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('student')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                        <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Salvar')); ?>

                                    </button>
                                </div>
                            </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>