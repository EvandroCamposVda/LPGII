

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    
                    <a href="/students/create" class="float-right btn btn-success">Novo Estudante</a>
                    Estudantes
                    <a href="/home" class="float btn btn-success">Inicio</a>
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table">
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>CPF</th>
                            <th>RG</th>
                            <th>Endereço</th>
                            <th>Telefone</th>
                            <th>Criado</th>
                            <th>Opções</th>
                        </tr>
                        
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($s->id); ?></td>
                                <td><?php echo e($s->name); ?></td>
                                <td><?php echo e($s->cpf); ?></td>
                                <td><?php echo e($s->rg); ?></td>
                                <td><?php echo e($s->address); ?></td>
                                <td><?php echo e($s->phone); ?></td>
                                <td><?php echo e($s->created_at); ?></td>
                                <td>
                                    <a href="/students/<?php echo e($s->id); ?>/edit" class="btn btn-primary btn-sm">Editar</a>

                                    <?php echo Form::open(['url' => "/students/$s->id", 'method' => 'delete']); ?>

                                        <?php echo e(Form::submit('Deletar', null, ["class" => "btn btn-warning"])); ?>

                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>